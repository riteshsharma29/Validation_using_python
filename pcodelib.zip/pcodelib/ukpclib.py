
"""
This library supports validating and formatting post codes for UK.
"""

import sys
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import sys
import os
import time
import pyautogui
import codecs
import time
from bs4 import BeautifulSoup

def test_pccode(code,join=True):

    if len(code) < 5 or len(code) > 9:
        print ("\n Error !!! Length of the Argument passed as postcode is invalid Minimum size is eg. A99AA, 5 letters | Maximum size is eg. DN55 1PT, 8 letters \n")
        sys.exit()		   
    code = code.upper()
    # From start up to the last 3 letters
    out_code = code[:-3].strip()
    # Only the last 3 letters
    inw_code = code[-3:].strip()
    if join:
        return out_code + ' ' + inw_code
    #return out_code, inw_code

    print ("Formatted UK Postcode is " + code + "\n")
    code = out_code + " " + inw_code
	
    driver = webdriver.Chrome(executable_path=os.path.join(os.getcwd(),'drivers\\chromedriver.exe'))
    driver.get("https://www.ukpostcode.co.uk/validate-postcode.htm#")
    codestr = driver.find_element_by_id("str_searchquery")
    codestr.send_keys(code)
    pyautogui.press('enter')
    time.sleep(20)
    html = driver.page_source
    soup = BeautifulSoup(html,"lxml")
    result = soup.find_all("p")
    print result[2].text
    driver.save_screenshot(code.replace(" ","_") + '_validation_result.png')
    driver.close()    
    

